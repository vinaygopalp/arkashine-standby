# from django.urls import path, include
# from .views import index

# urlpatterns = [
    # path('', include('djoser.urls')), #https://djoser.readthedocs.io/en/latest/base_endpoints.html#user-activate
    # path('', include('djoser.urls.authtoken')),
    # path('', include('djoser.urls.jwt')),
#       path('', include('knox.urls'))

# ]

# from django.urls import path
# from .api import LoginAPI, UserAPI
# from knox import views as knox_views

# urlpatterns = [
#     # path('register/', RegistrationAPI.as_view()),
#     path('login/', LoginAPI.as_view()),
#     path('user/', UserAPI.as_view()),
#     path('logout/', knox_views.LogoutView.as_view(), name='knox_logout'),

# ]

